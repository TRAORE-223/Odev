import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server{

        // Donne donne = new Donne(cacule, soket);

        private Cacule cacule;;
        private Socket soket;
    public void setServer(Cacule cacule) {
        this.cacule = cacule;

    }

    public void setSocket(Socket soket) {
        this.soket = soket;
    }


    protected double parseIslemi(String satir) throws Exception {
        double sonuc = Double.MAX_VALUE;
        String[] elementler = satir.split(":");
        if (elementler.length != 3)
            throw new IllegalArgumentException("donuc yapar..");
        double x = 0;
        double y = 0;
        try {
            x = Double.parseDouble(elementler[1]);
            y = Double.parseDouble(elementler[2]);
        } catch (Exception e) {
            throw new IllegalArgumentException("olumlu..");
        }
        switch (elementler[0].charAt(0)) {
            case '+':
                sonuc = cacule.add(x,y);
                break;
            case '-':
                sonuc = cacule.cikarma(x,y);
                break;
            case '*':
                sonuc = cacule.carpma(x,y);
                break;
            case '/':
                sonuc = cacule.bolme(x,y);
                break;
            default:
                throw new IllegalArgumentException("olumlu..");
        }
        return sonuc;
    }

    public void calistir() {

        try {
            BufferedReader okuyucu = new BufferedReader(new InputStreamReader(soket.getInputStream()));
            String satir = okuyucu.readLine();
            double result = parseIslemi(satir);
            BufferedWriter yazar = new BufferedWriter(new OutputStreamWriter(soket.getOutputStream()));
            yazar.write("" + result);
            yazar.newLine();
            yazar.flush();
            okuyucu.close();
            yazar.close();

        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    public static void main(String[] args) throws IOException {
        int port = 10000;
        if (args.length == 1) {
            try {
                port = Integer.parseInt(args[0]);
            }
            catch(Exception e){
            }
        }
        System.out.println("math server calis :");
        ServerSocket sunucuSoket = new ServerSocket(port);
        Socket soket = sunucuSoket.accept();
        Server server = new Server();
        server.setServer(new Cacule());
        server.setSocket(soket);
        server.calistir();
        sunucuSoket.close();
    }

}
