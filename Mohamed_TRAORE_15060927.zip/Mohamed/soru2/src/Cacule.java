
public class Cacule {


    public double cikarma(double x, double y){
        return (x-y);
    }
    public double carpma(double x, double y) {
        return  (x * y);
    }
    public double sin (double x) {
        return Math.sin(x);
    }

    public double cos (double x) {
        return Math.cos(x);
    }

    public double sqrt (double x) {
        return Math.sqrt(x);
    }

    public double add(double x,double y){
        return (x + y);
    }
    public double bolme (double x, double y) throws Exception {
        if(y != 0){
            return (x/y) ;
        }
        else {
            throw new ArithmeticException("0 le bolmez");
        }
    }
}
