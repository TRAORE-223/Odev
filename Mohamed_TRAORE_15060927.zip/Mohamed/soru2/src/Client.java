import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;

public class Client {

    public static void main(String[] args) {
        String hostname = "localhost";
        int port = 10000;
        if(args.length != 2) {
            System.out.println("Istemci calismakta...");
        }
        else {
            hostname = args[0];
            port = Integer.parseInt(args[1]);
        }
        try {
            Socket soket = new Socket(hostname, port);
            BufferedWriter yazar = new BufferedWriter(new OutputStreamWriter(soket.getOutputStream()));

            yazar.write("/:36:100");
            yazar.newLine();
            yazar.flush();
            // get the result from the server
            BufferedReader okuyucu = new BufferedReader(new InputStreamReader(soket.getInputStream()));
            System.out.println(okuyucu.readLine());
            okuyucu.close();
            yazar.close();
            soket.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
