public class Node {

    public enum Type{
        Peer,
        Cluster_leader,
        Virtual_cluster_leader
    }

}
