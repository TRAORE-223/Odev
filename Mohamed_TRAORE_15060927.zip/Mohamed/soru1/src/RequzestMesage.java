public enum RequzestMesage{

    JOIN_REQUEST,
    JOIN_REPLY,
    JOIN_CLUSTER,
    FORM_NEW_CLUSTER,
    CLUSTER_SPLIT,
    JOIN_ME,
    LEAVE,
    RTT

}
