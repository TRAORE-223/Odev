
public class Messager {

    private Object Content;
    private int senderID;

    private int senderPort;

    public enum Type {


    }

    private Type type;

    public Object getContent() {
        return Content;
    }

    public void setContent(Object content) {
        Content = content;
    }

    public int getSenderID() {
        return senderID;
    }

    public void setSenderID(int senderID) {
        this.senderID = senderID;
    }

    public int getSenderPort() {
        return senderPort;
    }

    public void setSenderPort(int senderPort) {
        this.senderPort = senderPort;
    }

    public int getSenderPortNumber() {
        return senderPortNumber;
    }

    public void setSenderPortNumber(int senderPortNumber) {
        this.senderPortNumber = senderPortNumber;
    }

    public int getRequestedService() {
        return requestedService;
    }

    public void setRequestedService(int requestedService) {
        this.requestedService = requestedService;
    }

    public int getSearchNodeID() {
        return searchNodeID;
    }

    public void setSearchNodeID(int searchNodeID) {
        this.searchNodeID = searchNodeID;
    }

    public int getRequesterPortNumber() {
        return requesterPortNumber;
    }

    public void setRequesterPortNumber(int requesterPortNumber) {
        this.requesterPortNumber = requesterPortNumber;
    }

    private int senderPortNumber;


    private int requestedService;

    private int searchNodeID;

    private int requesterPortNumber;


}
